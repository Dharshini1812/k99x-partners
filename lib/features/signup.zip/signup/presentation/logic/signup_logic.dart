// lib/features/signup/presentation/logic/signup_logic.dart
//
// Backs the single SignUpPage (the 5-step accordion). There's no separate
// OTP step anymore, so the mobile number is just a regular validated field
// here alongside dealer name, business name, address, pincode, city/state.

import 'package:dealer/core/services/name_match_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/model/onboarding_model.dart';

final signUpLogicProvider = Provider<SignUpLogic>((ref) {
  final logic = SignUpLogic();
  ref.onDispose(logic.dispose);
  return logic;
});

/// Which of the 5 accordion sections is open (-1 = none).
final expandedSectionProvider = StateProvider<int>((ref) => 0);

/// Per-section completion, drives the green check-mark in the header.
final sectionCompleteProvider =
    StateProvider<List<bool>>((ref) => List.filled(5, false));

final nameMatchStatusProvider =
    StateProvider<NameMatchStatus>((ref) => NameMatchStatus.notChecked);

class SignUpLogic {
  final dealerNameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final phoneFocus = FocusNode();
  final businessNameCtrl = TextEditingController();
  final businessAddressCtrl = TextEditingController();
  final pincodeCtrl = TextEditingController();
  final cityStateCtrl = TextEditingController();

  final images = OnboardingImages();
  final nameMatchService = NameMatchService();

  String? aadhaarGuessedName;
  String? panGuessedName;

  bool get isBusinessInfoValid =>
      dealerNameCtrl.text.trim().isNotEmpty &&
      phoneCtrl.text.trim().length == 10 &&
      businessNameCtrl.text.trim().isNotEmpty &&
      businessAddressCtrl.text.trim().isNotEmpty &&
      pincodeCtrl.text.trim().length == 6 &&
      cityStateCtrl.text.trim().isNotEmpty;

  bool get isOwnerPhotoValid =>
      images.ownerSelfie != null && images.placeOfBusiness != null;

  bool get isPersonalDocsValid =>
      images.aadhaarFront != null &&
      images.aadhaarBack != null &&
      images.panCard != null;

  /// Runs OCR on the Aadhaar + PAN photos and fuzzy-compares the names.
  /// Callers should show this as a dismissible warning, not a hard block —
  /// OCR on a phone photo of an ID card is never fully reliable.
  Future<NameMatchStatus> checkNameMatch() async {
    if (images.aadhaarFront == null || images.panCard == null) {
      return NameMatchStatus.notChecked;
    }
    try {
      final aadhaar = await nameMatchService.extractText(images.aadhaarFront!);
      final pan = await nameMatchService.extractText(images.panCard!);
      aadhaarGuessedName = aadhaar.guessedName;
      panGuessedName = pan.guessedName;

      if (aadhaarGuessedName == null || panGuessedName == null) {
        return NameMatchStatus.failed;
      }
      return nameMatchService.namesLikelyMatch(
              aadhaarGuessedName!, panGuessedName!)
          ? NameMatchStatus.matched
          : NameMatchStatus.mismatched;
    } catch (_) {
      return NameMatchStatus.failed;
    }
  }

  void dispose() {
    dealerNameCtrl.dispose();
    phoneCtrl.dispose();
    phoneFocus.dispose();
    businessNameCtrl.dispose();
    businessAddressCtrl.dispose();
    pincodeCtrl.dispose();
    cityStateCtrl.dispose();
    nameMatchService.dispose();
  }
}
