import 'package:dealer/features/live_auction/data/datasource/datasource.dart';
import 'package:dealer/features/live_auction/data/model/a_vehicle_detail.dart';
import 'package:dealer/features/live_auction/data/model/auction_vehicle.dart';
import 'package:dealer/features/live_auction/data/model/ocb_vehicle.dart';
import 'package:dealer/features/live_auction/presentation/mockapi.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:dealer/core/pagination/paginated_state.dart';

final auctionApiProvider = Provider<AuctionApi>((ref) {
  return MockAuctionApi();
  // return RemoteAuctionApi(ref.watch(dioProvider)); // swap when backend's ready
});

class AuctionListNotifier extends PaginatedNotifier<AuctionVehicle> {
  @override
  Future<List<AuctionVehicle>> fetchPage(int page) =>
      ref.read(auctionApiProvider).fetchAuctions(page: page);
}

final auctionListProvider =
    AsyncNotifierProvider<AuctionListNotifier, PaginatedState<AuctionVehicle>>(
        AuctionListNotifier.new);

class OcbListNotifier extends PaginatedNotifier<OcbVehicle> {
  @override
  Future<List<OcbVehicle>> fetchPage(int page) =>
      ref.read(auctionApiProvider).fetchOneClickBuy(page: page);
}

final ocbListProvider =
    AsyncNotifierProvider<OcbListNotifier, PaginatedState<OcbVehicle>>(
        OcbListNotifier.new);

final auctionSubTabProvider = StateProvider<int>((ref) => 0);

final vehicleDetailProvider =
    FutureProvider.family<VehicleDetail, String>((ref, id) {
  return ref.watch(auctionApiProvider).fetchVehicleDetail(id);
});
