import 'package:cached_network_image/cached_network_image.dart';
import 'package:dealer/features/live_auction/data/model/auction_vehicle.dart';
import 'package:dealer/features/live_auction/data/model/ocb_vehicle.dart';
import 'package:flutter/material.dart';
import 'package:dealer/core/theme/colors.dart';
import 'countdown_text.dart';

class _CardShell extends StatelessWidget {
  final String? imageUrl;
  final String locationLabel;
  final String title;
  final String specs;
  final Widget footer;

  const _CardShell({
    required this.imageUrl,
    required this.locationLabel,
    required this.title,
    required this.specs,
    required this.footer,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(.05),
              blurRadius: 16,
              offset: const Offset(0, 4)),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _ImageBlock(imageUrl: imageUrl, locationLabel: locationLabel),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Color(0xff1E293B)),
                ),
                const SizedBox(height: 4),
                Text(
                  specs,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style:
                      const TextStyle(fontSize: 13, color: Color(0xff64748B)),
                ),
                const SizedBox(height: 10),
                const Divider(height: 1, color: Color(0xffEEF1F5)),
                const SizedBox(height: 10),
                footer,
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ImageBlock extends StatelessWidget {
  final String? imageUrl;
  final String locationLabel;
  const _ImageBlock({required this.imageUrl, required this.locationLabel});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 180,
      width: double.infinity,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Container(
            color: const Color(0xffEEF1F5),
            child: imageUrl == null
                ? const Center(
                    child: Icon(Icons.directions_car_rounded,
                        size: 40, color: Color(0xff94A3B8)))
                : CachedNetworkImage(
                    imageUrl: imageUrl!,
                    fit: BoxFit.cover,
                    placeholder: (_, __) => const Center(
                      child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2)),
                    ),
                    errorWidget: (_, __, ___) => const Center(
                        child: Icon(Icons.directions_car_rounded,
                            size: 40, color: Color(0xff94A3B8))),
                  ),
          ),
          Positioned(top: 12, right: 12, child: _FavoriteButton()),
          Positioned(
            bottom: 10,
            left: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                  color: Colors.black.withOpacity(.55),
                  borderRadius: BorderRadius.circular(6)),
              child: Text(locationLabel,
                  style: const TextStyle(
                      fontSize: 11,
                      color: Colors.white,
                      fontWeight: FontWeight.w500)),
            ),
          ),
        ],
      ),
    );
  }
}

class _FavoriteButton extends StatefulWidget {
  @override
  State<_FavoriteButton> createState() => _FavoriteButtonState();
}

class _FavoriteButtonState extends State<_FavoriteButton> {
  bool _saved = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => setState(() => _saved = !_saved),
      child: Container(
        width: 32,
        height: 32,
        decoration:
            const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
        child: Icon(
          _saved ? Icons.favorite : Icons.favorite_border,
          size: 16,
          color: _saved ? const Color(0xffDC2626) : const Color(0xff64748B),
        ),
      ),
    );
  }
}

Widget _labelValue(String label, String value, {Color? valueColor}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label,
          style: const TextStyle(fontSize: 11, color: Color(0xff94A3B8))),
      const SizedBox(height: 2),
      Text(value,
          style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: valueColor ?? const Color(0xff1E293B))),
    ],
  );
}

Widget _cta(String label, {required bool filled, required VoidCallback onTap}) {
  return SizedBox(
    height: 44,
    child: filled
        ? ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: onTap,
            child: Text(label,
                style:
                    const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          )
        : OutlinedButton(
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.primary,
              side: const BorderSide(color: AppColors.primary, width: 1.5),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: onTap,
            child: Text(label,
                style:
                    const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          ),
  );
}

class AuctionVehicleCard extends StatelessWidget {
  final AuctionVehicle vehicle;
  const AuctionVehicleCard({super.key, required this.vehicle});

  @override
  Widget build(BuildContext context) {
    return _CardShell(
      imageUrl: vehicle.imageUrl,
      locationLabel: '${vehicle.city} · ${vehicle.regNo}',
      title: vehicle.title,
      specs:
          '${vehicle.fuelType} · ${vehicle.transmission} · ${vehicle.km}km · ${vehicle.ownerLabel}',
      footer: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _labelValue(
                  'Current bid', '₹${vehicle.currentBid.toStringAsFixed(0)}',
                  valueColor: const Color(0xff16A34A)),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text('Ends in',
                      style: TextStyle(fontSize: 11, color: Color(0xff94A3B8))),
                  CountdownText(
                    endsAt: vehicle.auctionEndsAt,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Color(0xffDC2626)),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _cta('Bid now', filled: true, onTap: () {})),
            const SizedBox(width: 8),
            Expanded(child: _cta('Autobid', filled: false, onTap: () {})),
          ]),
        ],
      ),
    );
  }
}

class OcbVehicleCard extends StatelessWidget {
  final OcbVehicle vehicle;
  const OcbVehicleCard({super.key, required this.vehicle});

  @override
  Widget build(BuildContext context) {
    return _CardShell(
      imageUrl: vehicle.imageUrl,
      locationLabel: '${vehicle.city} · ${vehicle.regNo}',
      title: vehicle.title,
      specs:
          '${vehicle.fuelType} · ${vehicle.transmission} · ${vehicle.km}km · ${vehicle.ownerLabel}',
      footer: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            if (vehicle.extScore != null) _score('Ext', vehicle.extScore!),
            const SizedBox(width: 14),
            if (vehicle.engScore != null) _score('Eng', vehicle.engScore!),
            const Spacer(),
            CountdownText(
                endsAt: vehicle.priceValidUntil,
                style: const TextStyle(fontSize: 12, color: Color(0xff94A3B8))),
          ]),
          const SizedBox(height: 10),
          const Text('OCB price',
              style: TextStyle(fontSize: 11, color: Color(0xff94A3B8))),
          Text('₹${vehicle.ocbPrice.toStringAsFixed(0)}',
              style:
                  const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: SizedBox(
                height: 52,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.primary,
                    side:
                        const BorderSide(color: AppColors.primary, width: 1.5),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: () {},
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('Quote price',
                          style: TextStyle(
                              fontSize: 13, fontWeight: FontWeight.w600)),
                      Text('From ₹${vehicle.quoteFromPrice.toStringAsFixed(0)}',
                          style: const TextStyle(
                              fontSize: 11, color: Color(0xff94A3B8))),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(child: _cta('Buy', filled: true, onTap: () {})),
          ]),
        ],
      ),
    );
  }

  Widget _score(String label, double v) => Text(
        '$label ${v.toStringAsFixed(0)}',
        style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: v >= 4 ? const Color(0xff16A34A) : const Color(0xffCA8A04)),
      );
}
