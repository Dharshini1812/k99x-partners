import 'package:collection/collection.dart';
import 'package:dealer/features/live_auction/data/datasource/datasource.dart';
import 'package:dealer/features/live_auction/data/model/a_vehicle_detail.dart';
import 'package:dealer/features/live_auction/data/model/auction_vehicle.dart';
import 'package:dealer/features/live_auction/data/model/listing_type.dart';
import 'package:dealer/features/live_auction/data/model/ocb_vehicle.dart';

class MockAuctionApi implements AuctionApi {
  static final _auctions = <AuctionVehicle>[
    AuctionVehicle(
      id: 'a1',
      title: '2023 Hyundai Creta SX (O)',
      city: 'Chennai',
      regNo: 'UNREGISTERED',
      fuelType: 'Petrol',
      transmission: 'Automatic',
      ownerLabel: '1st owner',
      km: 7500,
      imageUrl: null,
      currentBid: 1832000,
      auctionEndsAt: DateTime.now().add(const Duration(hours: 24, minutes: 46)),
    ),
    AuctionVehicle(
      id: 'a2',
      title: '2019 Maruti Suzuki Baleno Alpha',
      city: 'Chennai',
      regNo: 'TN07 IJ 7890',
      fuelType: 'Petrol',
      transmission: 'Manual',
      ownerLabel: '2nd owner',
      km: 51200,
      imageUrl: null,
      currentBid: 699000,
      auctionEndsAt: DateTime.now().add(const Duration(hours: 24, minutes: 46)),
    ),
    AuctionVehicle(
      id: 'a3',
      title: '2016 Toyota Corolla Altis VL AT',
      city: 'Coimbatore',
      regNo: 'TN07',
      fuelType: 'Petrol',
      transmission: 'Automatic',
      ownerLabel: '4th owner',
      km: 95000,
      imageUrl: null,
      currentBid: 441000,
      auctionEndsAt: DateTime.now().add(const Duration(hours: 2, minutes: 10)),
    ),
  ];

  static final _ocb = <OcbVehicle>[
    OcbVehicle(
      id: 'o1',
      title: '2019 Santro Sportz',
      city: 'Chennai',
      regNo: 'TN10',
      fuelType: 'Petrol',
      transmission: 'Manual',
      ownerLabel: '1st owner',
      km: 29900,
      imageUrl: null,
      ocbPrice: 412000,
      quoteFromPrice: 383000,
      extScore: 4,
      engScore: 4,
      priceValidUntil:
          DateTime.now().add(const Duration(hours: 3, minutes: 23)),
    ),
    OcbVehicle(
      id: 'o2',
      title: '2016 Celerio VXI',
      city: 'Chennai',
      regNo: 'TN10',
      fuelType: 'Petrol',
      transmission: 'Automatic',
      ownerLabel: '1st owner',
      km: 42000,
      imageUrl: null,
      ocbPrice: 285000,
      quoteFromPrice: 260000,
      extScore: 3,
      engScore: 4,
      priceValidUntil:
          DateTime.now().add(const Duration(hours: 14, minutes: 39)),
    ),
  ];

  @override
  Future<List<AuctionVehicle>> fetchAuctions(
      {int page = 1, int limit = 10}) async {
    await Future.delayed(const Duration(milliseconds: 400));
    if (page > 1) return [];
    return _auctions;
  }

  @override
  Future<List<OcbVehicle>> fetchOneClickBuy(
      {int page = 1, int limit = 10}) async {
    await Future.delayed(const Duration(milliseconds: 400));
    if (page > 1) return [];
    return _ocb;
  }

  @override
  Future<VehicleDetail> fetchVehicleDetail(String id) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final a = _auctions.firstWhereOrNull((v) => v.id == id);
    if (a != null) {
      return VehicleDetail(
        id: a.id,
        title: a.title,
        city: a.city,
        regNo: a.regNo,
        fuelType: a.fuelType,
        transmission: a.transmission,
        color: 'White',
        ownerLabel: a.ownerLabel,
        images: const [],
        km: a.km,
        type: ListingType.auction,
        currentBid: a.currentBid,
        auctionEndsAt: a.auctionEndsAt,
        bidIncrement: 5000,
        securityDeposit: 10000,
      );
    }
    final o = _ocb.firstWhere((v) => v.id == id);
    return VehicleDetail(
      id: o.id,
      title: o.title,
      city: o.city,
      regNo: o.regNo,
      fuelType: o.fuelType,
      transmission: o.transmission,
      color: 'White',
      ownerLabel: o.ownerLabel,
      images: const [],
      km: o.km,
      type: ListingType.ocb,
      ocbPrice: o.ocbPrice,
      quoteFromPrice: o.quoteFromPrice,
      fairValue: o.ocbPrice * 1.05,
      priceValidUntil: o.priceValidUntil,
    );
  }
}
