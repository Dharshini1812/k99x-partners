class AuctionVehicle {
  final String id, title, city, regNo, fuelType, transmission, ownerLabel;
  final String? imageUrl;
  final int km;
  final double currentBid;
  final DateTime auctionEndsAt;

  AuctionVehicle({
    required this.id,
    required this.title,
    required this.city,
    required this.regNo,
    required this.fuelType,
    required this.transmission,
    required this.ownerLabel,
    required this.km,
    this.imageUrl,
    required this.currentBid,
    required this.auctionEndsAt,
  });

  factory AuctionVehicle.fromJson(Map<String, dynamic> j) => AuctionVehicle(
        id: j['id'].toString(),
        title: j['title'],
        city: j['city'],
        regNo: j['regNo'] ?? 'UNREGISTERED',
        fuelType: j['fuelType'],
        transmission: j['transmission'],
        ownerLabel: j['ownerLabel'],
        km: j['km'],
        imageUrl: j['imageUrl'],
        currentBid: (j['currentBid'] as num).toDouble(),
        auctionEndsAt: DateTime.parse(j['auctionEndsAt']),
      );
}
