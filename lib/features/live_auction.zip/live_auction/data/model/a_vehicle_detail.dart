import 'listing_type.dart';

class VehicleDetail {
  final String id,
      title,
      city,
      regNo,
      fuelType,
      transmission,
      color,
      ownerLabel;
  final List<String> images;
  final int km;
  final ListingType type;

  final double? currentBid;
  final DateTime? auctionEndsAt;
  final double? bidIncrement;
  final double? securityDeposit;

  final double? ocbPrice;
  final double? quoteFromPrice;
  final double? fairValue;
  final DateTime? priceValidUntil;

  VehicleDetail({
    required this.id,
    required this.title,
    required this.city,
    required this.regNo,
    required this.fuelType,
    required this.transmission,
    required this.color,
    required this.ownerLabel,
    required this.images,
    required this.km,
    required this.type,
    this.currentBid,
    this.auctionEndsAt,
    this.bidIncrement,
    this.securityDeposit,
    this.ocbPrice,
    this.quoteFromPrice,
    this.fairValue,
    this.priceValidUntil,
  });

  factory VehicleDetail.fromJson(Map<String, dynamic> j) => VehicleDetail(
        id: j['id'].toString(),
        title: j['title'],
        city: j['city'],
        regNo: j['regNo'] ?? 'UNREGISTERED',
        fuelType: j['fuelType'],
        transmission: j['transmission'],
        color: j['color'],
        ownerLabel: j['ownerLabel'],
        images: List<String>.from(j['images'] ?? []),
        km: j['km'],
        type: j['type'] == 'ocb' ? ListingType.ocb : ListingType.auction,
        currentBid: (j['currentBid'] as num?)?.toDouble(),
        auctionEndsAt: j['auctionEndsAt'] != null
            ? DateTime.parse(j['auctionEndsAt'])
            : null,
        bidIncrement: (j['bidIncrement'] as num?)?.toDouble(),
        securityDeposit: (j['securityDeposit'] as num?)?.toDouble(),
        ocbPrice: (j['ocbPrice'] as num?)?.toDouble(),
        quoteFromPrice: (j['quoteFromPrice'] as num?)?.toDouble(),
        fairValue: (j['fairValue'] as num?)?.toDouble(),
        priceValidUntil: j['priceValidUntil'] != null
            ? DateTime.parse(j['priceValidUntil'])
            : null,
      );
}
